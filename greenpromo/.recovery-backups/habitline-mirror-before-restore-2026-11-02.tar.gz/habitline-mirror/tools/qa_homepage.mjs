#!/usr/bin/env node

import { chromium } from "playwright";

const baseURL = process.env.GREENPROMO_URL || "http://localhost:9000/";
const browser = await chromium.launch({
  headless: true,
  executablePath: "/usr/bin/google-chrome",
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});

const viewports = [
  { name: "desktop", width: 1440, height: 1000 },
  { name: "tablet", width: 768, height: 1024 },
  { name: "mobile", width: 390, height: 844 },
];

let failed = false;

for (const viewport of viewports) {
  const page = await browser.newPage({ viewport });
  const errors = [];
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(`console: ${message.text()}`);
  });
  page.on("pageerror", (error) => errors.push(`page: ${error.message}`));

  const response = await page.goto(baseURL, { waitUntil: "networkidle" });
  if (!response?.ok()) errors.push(`HTTP ${response?.status() ?? "unknown"}`);
  await page.evaluate(() => document.fonts.ready);

  await page.evaluate(() => window.scrollTo(0, Math.min(900, document.body.scrollHeight / 4)));
  await page.waitForTimeout(350);

  const pageChecks = await page.evaluate(() => {
    const brokenImages = [...document.images]
      .filter((image) => image.currentSrc && image.naturalWidth === 0)
      .map((image) => image.currentSrc);
    const overflow = document.documentElement.scrollWidth - document.documentElement.clientWidth;
    return { brokenImages, overflow };
  });

  if (pageChecks.brokenImages.length) errors.push(`broken images: ${pageChecks.brokenImages.join(", ")}`);
  if (pageChecks.overflow > 2) errors.push(`horizontal overflow: ${pageChecks.overflow}px`);

  const sections = viewport.name === "desktop"
    ? [
        ["hero", 0],
        ["intro", 0.12],
        ["services", 0.25],
        ["process", 0.40],
        ["pricing", 0.53],
        ["documentation", 0.66],
        ["coverage", 0.76],
        ["audiences", 0.86],
        ["faq", 0.94],
        ["footer", 1],
      ]
    : [["hero", 0], ["middle", 0.52], ["footer", 1]];

  const maxScroll = await page.evaluate(() => document.documentElement.scrollHeight - innerHeight);
  for (const [label, fraction] of sections) {
    await page.evaluate((top) => window.scrollTo(0, top), Math.round(maxScroll * fraction));
    await page.waitForTimeout(180);
    await page.screenshot({ path: `/tmp/greenpromo-${viewport.name}-${label}.png`, animations: "disabled" });
  }

  if (viewport.name === "desktop") {
    await page.locator("#usecase nav button").nth(1).click();
    await page.locator("#usecase nav button").nth(3).click();
    await page.locator(".story-next").click();
    await page.locator(".hs-accordion-toggle").last().click();
  } else if (viewport.name === "mobile") {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.locator('[data-hs-overlay="#mobile-menu"]').click();
    await page.waitForTimeout(150);
    const expanded = await page.locator('[data-hs-overlay="#mobile-menu"]').getAttribute("aria-expanded");
    if (expanded !== "true") errors.push("mobile menu did not open");
  }

  console.log(`${viewport.name}: ${errors.length ? `FAIL — ${errors.join(" | ")}` : "PASS"}`);
  failed ||= errors.length > 0;
  await page.close();
}

await browser.close();
process.exitCode = failed ? 1 : 0;
