# GreenPromo Habitline mirror

This directory contains two persistent copies:

- `reference/`: untouched local mirror of the Habitline source.
- `site/`: GreenPromo copy with localized content, production media, and a scoped visual polish layer.

The original `assets/app.css` remains byte-for-byte at the start of the generated stylesheet. `assets/greenpromo-polish.css` is appended as the only approved visual override. The original `assets/app.js`, HTML element order, classes, visible copy, and section structure remain protected by `tools/verify_mirror.py`.

## Reapply content

```bash
python3 tools/apply_greenpromo_content.py
python3 tools/verify_mirror.py
```

The apply script always starts from `reference/`, refreshes CSS-background media, and rebuilds `site/assets/app.css`, so repeated runs are deterministic.

## Run locally

```bash
python3 -m http.server 9000 --directory site
```

Open `http://localhost:9000/`.
